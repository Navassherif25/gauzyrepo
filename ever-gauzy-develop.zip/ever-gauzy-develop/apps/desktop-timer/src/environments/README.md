# Env files

Directory for auto-generated environment.ts and environment.prod.ts files
