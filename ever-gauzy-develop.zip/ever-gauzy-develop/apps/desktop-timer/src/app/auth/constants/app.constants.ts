export const API_PREFIX: string = '/api';
