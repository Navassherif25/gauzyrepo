gauzy desktop with nstudio electron

how to:

-   install dependencies

```bash

yarn install

```

**build executable for mac**

rebuild sqlite3 for mac

```bash
yarn build:sqlite:mac
```

build desktop

```bash
yarn build:desktop
```

build execute app

```bash
build:desktop:mac:quick
```

**build execute app for windows**
rebuild sqlite3 for windows

```bash
yarn build:sqlite:windows
```

build desktop

```bash
yarn build:desktop
```

build execute app

```bash
build:desktop:windows:quick
```

uninstall gauzy desktop macOS

```bash
- delete app data
$ rm -rf ~/Library/Application Support/gauzy-desktop
```
