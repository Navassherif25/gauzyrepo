declare module NodeJS {
	interface Global {
		variableGlobal: any;
	}
}
