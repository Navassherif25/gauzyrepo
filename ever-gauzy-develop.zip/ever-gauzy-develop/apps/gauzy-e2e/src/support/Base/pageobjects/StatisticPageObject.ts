export const StatisticPage = {
	headerTextCss: 'nb-card-header > h4',
	subheaderTextCss: 'nb-accordion-item-header > h6',
	accordionItemCss: 'nb-accordion-item-header',
	noDataTextCss: 'div.ng-star-inserted > span'
};
