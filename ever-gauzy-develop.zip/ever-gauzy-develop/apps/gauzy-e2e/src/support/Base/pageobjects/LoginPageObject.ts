export const LoginPage = {
	emailInputFieldCss: '#input-email',
	passwordInputFieldCss: '#input-password',
	loginButton: 'form > button[status="primary"]',
	loginHeadingCss: 'h1#title'
};
