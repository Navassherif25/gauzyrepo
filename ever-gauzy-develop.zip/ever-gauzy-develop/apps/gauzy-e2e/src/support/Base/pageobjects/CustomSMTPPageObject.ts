export const CustomSMTPPage = {
	hostInputCss: '#host',
	portInputCss: '#port',
	secureDropdownCss: '#secure',
	dropdownOptionCss: '.option-list nb-option',
	usernameInputCss: '#username',
	passwordInputCss: '#password',
	saveButtonCss: 'nb-card-footer.text-right > button[status="primary"]'
};
