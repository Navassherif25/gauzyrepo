export const RemoveUserPage = {
	gridButtonCss: 'div.layout-switch > button',
	selectTableRowCss: 'table > tbody > tr.ng2-smart-row',
	removeButtonCss: 'div.mb-3 > button[status="danger"]',
	confirmRemoveUserButtonCss: 'nb-card-footer > button[status="danger"]',
	toastrMessageCss: 'nb-toast.ng-trigger',
	verifyUserCss: 'ga-picture-name-tags > div > div.d-block'
};
