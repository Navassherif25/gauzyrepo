export const DeleteOrganizationPage = {
	gridButtonCss: 'div.layout-switch > button',
	confirmDeleteCss: 'nb-card > nb-card-footer > button',
	deleteButtonCss: 'button[status="danger"]'
};
