export const SettingsFeaturesPage = {
	headerTextCss: 'div.header > h4',
	subheaderTextCss: 'nb-card-header > header.ng-star-inserted',
	tabButtonCss: 'ul.route-tabset > li.route-tab > a.tab-link',
	nbToggleCss: 'div.col-6 > nb-toggle',
	checkboxCss: 'input.native-input',
	textCss: 'span.text',
	mainTextCss: 'div.row > div.text-left'
};
