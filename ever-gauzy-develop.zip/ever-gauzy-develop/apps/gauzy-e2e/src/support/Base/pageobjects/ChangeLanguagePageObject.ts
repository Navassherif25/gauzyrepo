export const ChangeLanguage ={
    settingsButtonCss: 'nb-actions.left > nb-action[ng-reflect-icon="settings-2-outline"]',
    languageDropdownCss: 'ngx-theme-settings > ngx-theme-language-selector > div > div',
    languageOptionsCss: 'ul.option-list > nb-option',
    createButtonCss: 'nb-action.show-large-up > button[status="success"]'
};