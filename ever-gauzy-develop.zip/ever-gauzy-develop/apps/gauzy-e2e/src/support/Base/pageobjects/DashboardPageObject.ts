export const DashboardPage = {
	createButtonCss: '[ng-reflect-tag="create-context-menu"]',
	userNameCss: '[class="info-container"] div',
	settingBlockCss: 'nb-card-body > .setting-block',
	settingBlockCssTwo: 'nb-card-body[class="settings-body"]>',
	childerElementCss: 'div[class="setting-block ng-star-inserted"]'
};
