export const MessageButton = {
	messageButtonCss:
		'nb-actions.left > nb-action[icon="message-circle-outline"]',
	menuItemCss: 'ul.menu-items > li.menu-item > a'
};
