export const SMSGatewaysPage = {
	headerTextCss: 'div.header > h4',
	subheaderTextCss: 'ga-sms-gateway > nb-card > nb-card-header',
	checkboxCss: 'div.toggle > span.toggle-switcher',
	inputCheckBoxCss: 'input.native-input'
};
