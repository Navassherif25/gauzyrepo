export const LogoutPage = {
	logoutButtonCss: '[title="Log out"]'
};
