export const CandidatesPageData = {
	candidateCountry: 'Bulgaria',
	candidateCity: 'Sofia',
	addressOne: 'Simeonovsko shose 104',
	postcode: 1700,
	payPeriod: 'Weekly',
	billRate: 99,
	schoolName: 'Cambridge',
	degreeDiploma: 'Bachelor'
};
