export const OrganizationRecurringExpensesPageData = {
	defaultExpense: 'Extra Bonus',
	editExpense: 'Rent',
	defaultValue: 99
};
