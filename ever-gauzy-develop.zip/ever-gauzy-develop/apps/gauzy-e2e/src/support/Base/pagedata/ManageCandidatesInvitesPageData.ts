export const ManageCandidatesInvitesPageData = {
    headerText: 'Manage Candidate Invites',
    tableResult: 1
};
