export const OrganizationTagsPageData = {
	tagName: 'Default',
	editTagName: 'Urgent',
	tagColor: '#e6880e',
	tagDescription: 'Only testing'
};
