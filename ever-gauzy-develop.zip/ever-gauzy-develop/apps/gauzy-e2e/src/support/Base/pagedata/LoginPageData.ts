export const LoginPageData = {
	TitleText: 'Gauzy',
	email: 'admin@ever.co',
	password: 'admin',
	empEmail: 'employee@ever.co',
	empPassword: '123456'
};
