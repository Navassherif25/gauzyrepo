export const InviteUserPageData = {
	role: 'Manager'
};
