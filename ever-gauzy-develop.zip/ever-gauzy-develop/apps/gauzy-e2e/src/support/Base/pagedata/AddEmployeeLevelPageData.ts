export const AddEmployeeLevelPageData = {
	levelE: 'Level E',
	levelF: 'Level F',
	levelD: 'Level D'
};
