export const OrganizationTeamsPageData = {
	name: 'Front-End Team',
	editName: 'Web Development',
	employeeDropdown: 1,
	managerDropdown: 1,
};
