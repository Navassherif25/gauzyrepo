export const OrganizationVendorsPageData = {
	vendorName: 'Dominos Pizza',
	editVendorName: 'JUMBO',
	vendorPhone: '0897564913',
	vendorEmail: 'dominos@pizza.com',
	vendorWebsite: 'https://www.dominos.bg/'
};
