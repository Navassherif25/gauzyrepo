export const OrganizationEmploymentTypesPageData = {
	name: 'Junior Front-End Developer',
	editName: 'Senior Front-End Developer'
};
