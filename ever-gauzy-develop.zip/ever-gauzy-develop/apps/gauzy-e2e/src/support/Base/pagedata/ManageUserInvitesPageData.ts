export const ManageUserInvitesPageData = {};
