export const AppsIntegrationsPageData = {
	header: 'Available Apps & Integrations',
	hubstaffHeader: 'Hubstaff',
	upworkHeader: 'Upwork',
	allIntegrations: 'All Integrations',
	forSalesTeams: 'For Sales Teams',
	forAccountants: 'For Accountants',
	forSupportTeams: 'For Support Teams',
	crm: 'CRM',
	scheduling: 'Scheduling',
	tools: 'Tools',
	all: 'All',
	free: 'Free',
	paid: 'Paid'
};
