export const TimeTrackingWithPausePageData = {
    firstTime: '00:00:08',
    secondTime: '00:00:05',
    tracked: 'TRACKED',
    timerTime: '00:00:00',
    urlConfirmDashboardLoad: '/api/employee-statistics/months*',
    firstTimeTable: 1, 
    secondTimeTable: 7, 
    firstDeleteBtn: 0,
    secondDeleteBtn: 1

}