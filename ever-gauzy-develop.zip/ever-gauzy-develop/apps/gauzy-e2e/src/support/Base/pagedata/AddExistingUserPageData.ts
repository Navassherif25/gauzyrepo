export const AddExistingUserPageData = {
	defaultUser: 'Local Admin'
};
