export const GoalsTimeFramePageData = {
	name: 'Q4-2021',
	editName: 'Q4-2022',
	emptyTableText: 'No data found'
};
