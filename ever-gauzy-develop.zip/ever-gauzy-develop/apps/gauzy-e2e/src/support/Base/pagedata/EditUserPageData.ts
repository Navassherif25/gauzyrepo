export const EditUserPageData = {
	role: 'Admin',
	preferredLanguage: 'English'
};
