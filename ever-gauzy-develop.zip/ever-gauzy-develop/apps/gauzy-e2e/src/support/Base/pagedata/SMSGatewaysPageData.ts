export const SMSGatewaysPageData = {
	headerText: 'Settings',
	subheaderText: 'SMS Provider'
};
