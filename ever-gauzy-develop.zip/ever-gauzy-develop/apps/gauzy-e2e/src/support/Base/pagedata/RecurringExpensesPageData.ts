export const RecurringExpensesPageData = {
	defaultExpense: 'Salary',
	defaultExpenseValue: '99.00',
	editExpenseValue: '98.00'
};
