export const ManageInterviewsPageData = {
	title: 'Interview #',
	note: 'No previous experience',
	location: 'Sofia, Simeonovsko shose 64',
	feedbackDescription: 'Amazing candidate, perfect for the position!',
	updatedNote: 'Might be late with 10 minutes'
};
