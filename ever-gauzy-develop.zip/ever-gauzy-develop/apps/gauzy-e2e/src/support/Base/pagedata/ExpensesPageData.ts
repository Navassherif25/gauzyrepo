export const ExpensePageData = {
	defaultCategory: 'Tax Deductable',
	defaultProject: 'Gauzy Web Site',
	defaultAmount: 99,
	defaultPurpose: 'Something to clear',
	defaultVendor: 'Domminos Pizza',
	date: 'Date',
	employee: 'Employee',
	project: 'Project',
	accounting: 'Accounting',
	reports: 'Reports',
	verifyAmount: '$99.00',
	expenses: 'Expenses',
	expense: 'Expense'
};
