export const GoalsKPIPageData = {
	name: 'Maintain page views',
	editName: 'Maintain scroll position',
	description: 'KPIs can be used as measurable metrics for Key results',
	value: 4,
	emptyTableText: 'No data found',
	tableResult: 1
};
