export const DangerZonePageData = {
	headerText: 'Settings',
	buttonText: 'Delete your account',
	confirmDeleteText:
		"Are you sure you want to delete your account?  If Yes, please type \'REMOVE ACCOUNT\' to confirm.",
	deleteUserText: 'REMOVE ALL DATA'
};
