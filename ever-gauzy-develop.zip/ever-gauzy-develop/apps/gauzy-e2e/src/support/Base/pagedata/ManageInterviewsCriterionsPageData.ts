export const ManageInterviewsCriterionsPageData = {
	technology: 'Node/Express JS',
	quality: 'Loyalty',
	editTechnology: 'Angular 2-10',
	editQuality: 'Communicative'
};
