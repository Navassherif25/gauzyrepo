export const ProjectTrackedInTimesheetPageData = {
    name: 'Gauzy Web Site',
    urlConfirmDashboardLoad: '/api/employee-statistics/months*'
};
