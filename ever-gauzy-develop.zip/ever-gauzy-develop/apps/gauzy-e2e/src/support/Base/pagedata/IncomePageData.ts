export const IncomePageData = {
	defaultAmount: 99,
	defaultNote: 'No bonus included'
};
