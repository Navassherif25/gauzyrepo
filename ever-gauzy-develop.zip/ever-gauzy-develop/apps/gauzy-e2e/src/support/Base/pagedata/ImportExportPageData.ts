export const ImportExportData = {
	headerText: 'Settings',
	subheaderText: 'Import / Export Data',
	firstInfo: 'Click "Import" to import your data into Gauzy DB.',
	secondInfo: 'Click "Export" to export data from Gauzy DB.',
	thirdInfo:
		'Click "Download Templates" to download Zip archive with CSV templates for the format of Gauzy data.',
	fileName: 'archive.zip',
	password: '12345678'
};
