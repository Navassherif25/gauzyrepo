export const TimesheetsPageData = {
	defaultDescription: 'Report progress on daily basis',
	editDescription: 'Create timesheet for reports',
	defaultProjectName: 'Gauzy Web Site'
};
