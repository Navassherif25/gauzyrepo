export const CustomSMTPPageData = {
	host: 'localhost',
	port: 3000,
	secure: 'True'
};
