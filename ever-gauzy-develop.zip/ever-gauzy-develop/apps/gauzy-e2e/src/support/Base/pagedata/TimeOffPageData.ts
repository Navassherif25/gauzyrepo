export const TimeOffPageData = {
	defaultPolicy: 'Default Policy',
	defaultDescription: 'Going to the sea',
	defaultHoliday: 'Нова Година',
	addNewPolicyData: 'TEST'
};
