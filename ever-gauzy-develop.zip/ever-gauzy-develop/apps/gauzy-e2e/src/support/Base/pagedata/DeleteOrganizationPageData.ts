export const DeleteOrganizationPageData = {
	currency: 'USD',
	dashboardCardText: 'Go to dashboard'
};
