export const ClientsData = {
	defaultProject: 'Gauzy Web Site',
	country: ' Bulgaria ',
	defaultPhone: '00359878561239',
	hours: 12,
	editButton: 1,
	clientType: 'CLIENT',
	tableResult: 1

};
