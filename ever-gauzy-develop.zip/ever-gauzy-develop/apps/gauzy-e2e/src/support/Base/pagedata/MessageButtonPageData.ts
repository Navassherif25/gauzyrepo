export const MessageButtonData = {
	supportChat: 'Support Chat',
	faq: 'FAQ',
	help: 'Help',
	about: 'About'
};
