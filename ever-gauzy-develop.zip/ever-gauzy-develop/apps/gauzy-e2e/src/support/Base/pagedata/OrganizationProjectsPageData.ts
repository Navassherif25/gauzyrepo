export const OrganizationProjectsPageData = {
	name: 'Gauzy Web Site',
	hours: 12,
	editName: 'Ever',
	description:
		'Open-Source Business Management Platform focused on Fairness and Transparency.',
	color: '#195e83',
	saveBtnIndex: 0
};
