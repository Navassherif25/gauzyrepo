export const StatisticPageData = {
	header: 'Statistic',
	overallRating: 'Overall rating',
	ratingInterview: 'Rating per interview',
	criterionRating: "Criterion's rating per interview",
	averageCriterion: "Average criterion's rating",
	noDataText: '|'
};
