export const ManageEmployeesPageData = {
	preferredLanguage: 'English',
	defaultProject: 'Gauzy Web Site'
};
