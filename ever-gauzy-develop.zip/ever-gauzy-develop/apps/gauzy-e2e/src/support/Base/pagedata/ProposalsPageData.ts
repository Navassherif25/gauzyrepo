export const ProposalsPageData = {
    juniorDeveloper: 'Junior Developer Template',
    seniorDeveloper: 'Senior Developer Template',
    headerTitleText: 'Proposals Management'
};
