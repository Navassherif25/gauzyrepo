export const EditProfilePageData = {
	preferredLanguage: 'English',
	email: 'local.admin@ever.co',
	password: 'admin',
	firstName: 'Admin',
	lastName: 'Local'
};
