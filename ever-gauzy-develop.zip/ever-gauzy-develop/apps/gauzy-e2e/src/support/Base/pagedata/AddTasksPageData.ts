export const AddTasksPageData = {
	defaultTaskProject: 'Gauzy Web Site',
	defaultTaskTitle: 'Feature: All Integrations should work with useHash',
	editTaskTitle: 'Feature: Invite users with emails',
	defaultTaskEstimateDays: 1,
	defaultTaskEstimateHours: 8,
	defaultTaskEstimateMinutes: 59,
	defaultTaskDescription: 'Very important task',
	tableResult: 1
};
