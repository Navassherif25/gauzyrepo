export const ChangeLanguagePageData = {
	Bulgarian: '+ Създаване',
	English: '+ Create',
    Russian: '+ Создать',
    Hebrew: '+ צור'
};