export const ApprovalRequestPageData = {
	defaultApprovalPolicy: 'Default Approval Policy',
	dafaultName: 'Request time off',
	defaultMinCount: 14,
	defaultpolicyDescription: 'Default Approval Policy',
	editName: 'Request holiday',
	approvalBtn: 'Approve',
	approvalRefuseBtnIndex: 7,
	approvalStatus: 'Approved',
	defaultRequest: 'request',
	searchResult: 1,
	refuseBtn: 'Refuse',
	refusedStatus: 'Refused'

};
