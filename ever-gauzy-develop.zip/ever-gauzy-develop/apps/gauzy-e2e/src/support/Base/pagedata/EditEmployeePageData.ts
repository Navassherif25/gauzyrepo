export const EditEmployeePageData = {
	preferredLanguage: 'English',
	linkedin: 'https://www.linkedin.com/in/yavor-grancharov-74023a1a0/',
	github: 'https://github.com/YavorGrancharov',
	upwork: 'https://www.upwork.com/freelancers/~01b502f689da97329e',
	description: 'Full-Stack Web Developer',
	country: 'Bulgaria',
	payPeriod: 'Weekly',
	weeklyLimits: 30,
	billRate: 35
};
