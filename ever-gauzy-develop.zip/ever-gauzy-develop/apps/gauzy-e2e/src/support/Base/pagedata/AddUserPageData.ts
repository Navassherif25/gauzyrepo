export const AddUserPageData = {
	role: 'MANAGER'
};
