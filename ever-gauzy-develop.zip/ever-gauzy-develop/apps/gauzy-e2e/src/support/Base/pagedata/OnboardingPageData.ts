export const OnboardingPageData = {
	currency: 'US Dollar',
	dashboardCardText: 'Go to dashboard'
};
