export const OrganizationDocumentsPageData = {
	documentName: 'Application for paid leave',
	editDocumentName: 'Application for unpaid leave'
};
