export const OrganizationEquipmentPageData = {
	name: 'Car',
	editName: 'Truck',
	type: 'Vehicle',
	sn: 12345678,
	year: 2015,
	cost: 8900,
	period: 365,
	requestName: 'BMW',
	editRequestName: 'Opel',
	policy: 'Default policy',
	editPolicy: 'Second policy',
	description: 'Shared between all employees'
};
