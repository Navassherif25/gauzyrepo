export const EventTypePageData = {
	dafaultEventTitle: '90 Minutes Event',
	defaultDescription: 'This is a default event type.',
	defaultDuration: '90 minute(s)'
};
