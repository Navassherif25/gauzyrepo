export const AddEmployeePositionPageData = {
	fullStackDeveloper: 'Full Stack Web Developer',
	midLevelWebDeveloper: 'Mid Level Web Developer',
	uxDesigner: 'UX Designer'
};
