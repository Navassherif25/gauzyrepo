export const AppointmentsPageData = {
	bookAppointmentButton: 'Book Public Appointment',
	header: 'Pick a date and time',
	appointmentConfirmed: 'Appointment Confirmed',
	agenda: 'Very important meeting',
	bufferTime: '10',
	location: 'Sofia, Simeonovsko shose 64',
	appointmentDescription:
		'Employee meeting for the most recent event in the company'
};
