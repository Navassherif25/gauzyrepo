export const PipelinesPageData = {
	pipelineName: 'Test',
	editPipelineName: 'Test 2',
	pipelineDescription: 'New pipeline added',
	nameInputIndex: 0,
	stageNameInputIndex: 1,
	stageName: 'The main stage',
	pipelineDescriptionIndex: 0,
	tableResult: 1,
	titleInputData: 'Big deal',
	dropdownOption: 0
};
