export const FileStoragePageData = {
	header: 'Settings - File Storage',
	subheader: 'S3 details',
	accessKeyId: 'replace_me',
	secretAccessKey: 'replace_me',
	region: 'Europe',
	bucket: 'my-eu-bucket-3'
};
