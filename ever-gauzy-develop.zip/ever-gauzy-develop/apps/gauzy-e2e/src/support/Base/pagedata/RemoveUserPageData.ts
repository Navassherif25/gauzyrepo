export const RemoveUserPageData = {};
