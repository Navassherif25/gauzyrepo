export const TimeTrackingForClientPageData = {
    mainTextDashboard: 'Total Income',
    urlConfirmDashboardLoad: '/api/employee-statistics/months*'
}