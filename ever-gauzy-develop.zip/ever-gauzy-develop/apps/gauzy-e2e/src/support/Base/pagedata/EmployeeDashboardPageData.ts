export const EmployeeDashboardPageData = {
    defaultExpense: 'Salary',
	defaultExpenseValue: '99.00',
    dashboardTxt: 'Dashboard',
    employeeSalary: 'Salary: BGN 99',
    accountingTxt: 'Accounting',
    incomeTxt: 'Income',
    incomeBtn: 2,
    anountInput: '250',
    defaultNote: 'No bonus included',
    dashboardIncomeTxt: '250.00',
    bonusTxt: 'Bonus : 113.25 USD',
    bgnCurrency: 'Bulgarian Lev (BGN)'
};