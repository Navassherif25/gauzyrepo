export const CustomersPageData = {
	defaultProject: 'Gauzy Web Site',
	defaultPhone: '00359878561239',
	country: 'Bulgaria',
	hours: 12,
	addBtn: 0,
	editBtn: 1
};
