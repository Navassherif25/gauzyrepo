export const OrganizationDepartmentsPageData = {
	departmentName: 'Front-End Development',
	editDepartmentName: 'Back-End Development'
};
