export const EmployeeAddInfoPageData = {
    level: 'Level',
    dashboardTxt: 'Dashboard',
    employmentTxt: 'Employment'

};