export const GoalsPageData = {
	name: 'Improve Website SEO',
	owner: 'Default Company',
	keyResultName: 'Add Metadata to improve SEO',
	weightParameter: 'Increase 2X'
};
