export const PaymentsPageData = {
	defaultPaymentMethod: 'Cash',
	defaultAmount: 99,
	defaultNote: 'Billable',
	defaultProject: 'Gauzy Web Site',
	reports: 'Reports',
	payments: 'Payments',
	verifyAmount: '$99.00',
	accounting: 'Accounting',
	date: 'Date',
	client: 'Client',
	project: 'Project'
};
